# LYRA Pro Max — Android floating voice assistant

This is a complete **source project** for an Android floating assistant prototype. It includes:
- Floating, draggable Lyra bubble over other apps
- Tap bubble to open a compact voice panel (not a full-screen home app)
- Hindi/English speech recognition and spoken replies
- Local commands for opening apps, web search, Wi-Fi/Bluetooth settings, volume, and torch
- Optional Gemini API integration using a key you supply
- GitHub Actions workflow to build a debug APK in the cloud

## Important limitations
- This is not a signed Play Store release and has not been built/tested on your specific phone from this environment.
- Android does not let an ordinary app control absolutely everything. Some actions require user confirmation, special permissions, or cannot be automated.
- The OS-reserved bottom swipe gesture is not freely replaceable on every Android skin. This project uses an overlay bubble; use Android's default-assistant settings if your phone offers that integration.
- AI replies require your own Gemini API key. Do not share the key with anyone or commit it publicly. The app stores it locally in app preferences.
- Voice recognition may use the phone's configured speech service and internet.

## Build without Android Studio
1. Create a GitHub repository and upload these project files.
2. Open **Actions** → **Build Lyra Pro Max APK** → **Run workflow**.
3. Download the `Lyra-Pro-Max-debug-apk` artifact from the completed workflow.
4. On your phone, install the APK (you may need to allow installs from your browser/files app).
5. Open Lyra once, grant **Display over other apps** and microphone permission, then tap **Start bubble**.
6. Optional: open **AI setup** in the compact panel and paste your Gemini API key.

Do not upload a file containing your API key to GitHub.
