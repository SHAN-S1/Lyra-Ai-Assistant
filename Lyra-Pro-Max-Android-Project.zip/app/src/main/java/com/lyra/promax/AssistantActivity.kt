package com.lyra.promax

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.content.Context
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread
import org.json.JSONObject
import org.json.JSONArray

class AssistantActivity : Activity() {
    private var tts: TextToSpeech? = null
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private var cameraId: String? = null
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN") }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 18, 20, 16)
            setBackgroundColor(Color.rgb(17, 20, 43))
        }
        root.addView(TextView(this).apply {
            text = "✦ LYRA"; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        transcript = TextView(this).apply {
            text = "Hi! Tap 🎙 and speak, or type a command."
            textSize = 15f; setTextColor(Color.LTGRAY); setPadding(0, 14, 0, 14)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 100))
        input = EditText(this).apply { hint = "Type a command…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(input)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(Button(this).apply { text = "🎙 Listen"; setOnClickListener { listenNow() } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "Send"; setOnClickListener { runCommand(input.text.toString().trim()); input.setText("") } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(Button(this).apply { text = "AI setup"; setOnClickListener { startActivity(Intent(this@AssistantActivity, SettingsActivity::class.java)) } }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(Button(this).apply { text = "Close"; setOnClickListener { finish() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row2)
        setContentView(root)
    }

    private fun listenNow() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this phone.")
            return
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { transcript.text = "Listening…"; }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                input.setText(spoken); runCommand(spoken); sr.destroy()
            }
            override fun onError(error: Int) { transcript.text = "I didn't catch that. Tap Listen and try again."; sr.destroy() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Lyra")
        })
    }

    private fun runCommand(raw: String) {
        val q = raw.trim()
        if (q.isBlank()) return
        val c = q.lowercase(Locale.ROOT)
        transcript.text = "You: $q\n\nWorking…"
        when {
            c.contains("youtube") -> openApp("com.google.android.youtube", "Opening YouTube")
            c.contains("free fire") -> openFirstApp(listOf("com.dts.freefireth", "com.dts.freefiremax"), "Opening Free Fire")
            c.contains("chrome") -> openApp("com.android.chrome", "Opening Chrome")
            c.contains("bluetooth") -> openSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "Opening Bluetooth settings")
            c.contains("wifi") || c.contains("wi-fi") -> openSettings(Settings.ACTION_WIFI_SETTINGS, "Opening Wi-Fi settings")
            c.contains("settings") || c.contains("setting kholo") -> openSettings(Settings.ACTION_SETTINGS, "Opening Settings")
            c.contains("volume up") || c.contains("volume badhao") || c.contains("awaaz badhao") -> changeVolume(1)
            c.contains("volume down") || c.contains("volume kam") || c.contains("awaaz kam") -> changeVolume(-1)
            c.contains("torch on") || c.contains("flashlight on") || c.contains("torch chalu") || c.contains("flashlight chalu") -> setTorch(true)
            c.contains("torch off") || c.contains("flashlight off") || c.contains("torch band") -> setTorch(false)
            c.startsWith("search ") || c.startsWith("google ") || c.contains("search karo") -> searchWeb(q)
            c == "help" || c.contains("kya kar sakti") || c.contains("commands") -> {
                reply("Try: YouTube kholo, Free Fire kholo, Wi-Fi settings, Bluetooth settings, settings kholo, volume badhao, volume kam karo, torch on, torch off, or search followed by your question.")
            }
            else -> askGemini(q)
        }
    }

    private fun openFirstApp(packages: List<String>, label: String) {
        val pkg = packages.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pkg == null) { reply("I couldn't find that app on your phone."); return }
        openApp(pkg, label)
    }
    private fun openApp(pkg: String, label: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { reply("That app is not installed or Android did not expose it."); return }
        say(label); startActivity(i); finish()
    }
    private fun openSettings(action: String, label: String) {
        try { say(label); startActivity(Intent(action)) }
        catch (_: Exception) { reply("Android couldn't open that settings page.") }
    }
    private fun changeVolume(direction: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        am.adjustStreamVolume(stream, if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        reply(if (direction > 0) "Media volume increased." else "Media volume decreased.")
    }
    private fun setTorch(enabled: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            if (cameraId == null) cameraId = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { reply("This phone doesn't expose a torch."); return }
            cm.setTorchMode(cameraId!!, enabled); torchOn = enabled
            reply(if (enabled) "Torch on." else "Torch off.")
        } catch (_: Exception) { reply("Torch control failed. Check camera permission or phone restrictions.") }
    }
    private fun searchWeb(query: String) {
        val term = query.removePrefix("search ").removePrefix("Search ").removePrefix("google ").trim()
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(term, "UTF-8")
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); finish() }
        catch (_: Exception) { reply("Couldn't open web search.") }
    }
    private fun askGemini(prompt: String) {
        val key = getSharedPreferences("lyra", MODE_PRIVATE).getString("gemini_key", "").orEmpty()
        if (key.isBlank()) {
            reply("I heard: $prompt. To answer general questions with AI, open AI setup and add your Gemini API key. You can also say YouTube kholo, torch on, volume badhao, or search followed by a query.")
            return
        }
        transcript.text = "You: $prompt\n\nLyra is thinking…"
        thread {
            var answer = "Sorry, I couldn't reach the AI service. Check your internet and API key."
            var conn: HttpURLConnection? = null
            try {
                val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + URLEncoder.encode(key, "UTF-8"))
                conn = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 20000
                    setRequestProperty("Content-Type", "application/json"); doOutput = true
                }
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are Lyra, a concise friendly Hindi-English phone assistant. Answer safely and clearly. User: $prompt")))))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode in 200..299) {
                    val json = JSONObject(response)
                    answer = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                } else answer = "AI service error (${conn.responseCode}). Check your API key or quota."
            } catch (_: Exception) { }
            finally { conn?.disconnect() }
            runOnUiThread { reply(answer) }
        }
    }
    private fun say(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lyra_reply") }
    private fun reply(text: String) {
        transcript.text = text
        say(text)
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
