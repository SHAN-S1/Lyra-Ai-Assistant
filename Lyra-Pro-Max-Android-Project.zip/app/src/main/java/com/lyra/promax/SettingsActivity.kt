package com.lyra.promax

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("lyra", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(15, 18, 35))
        }
        root.addView(TextView(this).apply {
            text = "LYRA AI SETUP"; textSize = 24f; setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Optional: paste your Gemini API key to enable AI-generated replies. Keep it private and do not upload it to GitHub."
            textSize = 15f; setTextColor(Color.LTGRAY); setPadding(0, 16, 0, 16)
        })
        val key = EditText(this).apply {
            hint = "Gemini API key (optional)"
            setSingleLine(true)
            setText(prefs.getString("gemini_key", ""))
        }
        root.addView(key)
        root.addView(Button(this).apply {
            text = "Save key"
            setOnClickListener {
                prefs.edit().putString("gemini_key", key.text.toString().trim()).apply()
                finish()
            }
        })
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { finish() } })
        setContentView(root)
    }
}
