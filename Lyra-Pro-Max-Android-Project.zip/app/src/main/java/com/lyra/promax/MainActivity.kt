package com.lyra.promax

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 30, 26, 30)
            setBackgroundColor(Color.rgb(12, 15, 32))
        }
        root.addView(TextView(this).apply {
            text = "LYRA  •  PRO MAX"
            textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Your floating voice assistant\n\n1. Allow overlay permission\n2. Start the bubble\n3. Tap the bubble and speak\n\nThe assistant bubble can be dragged around the screen."
            textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY)
            setPadding(0, 22, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "Start Lyra bubble"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, BubbleService::class.java))
                    finish()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Stop Lyra bubble"
            setOnClickListener { stopService(Intent(this@MainActivity, BubbleService::class.java)) }
        })
        root.addView(Button(this).apply {
            text = "AI setup"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        setContentView(root)
    }
}
